from pathlib import Path
import json,subprocess,hashlib
OUT=Path(__file__).resolve().parent
row=json.loads((OUT/'review3371-ro-r6-base-launch.json').read_text())
roots={k:Path(v) for k,v in row['exports'].items()}
products=['_shared/skill_compliance_check.py','programs/project_outputs_in_tree_check.py','programs/flow_compliance_check.py','programs/rtl_hygiene_lint.py','programs/interface_encoding_audit.py']
tests=['programs/tests/test_project_outputs_in_tree_check.py','programs/tests/test_interface_encoding_audit.py','programs/tests/test_issue3252_native_sv_driver.py','programs/tests/test_issue3378_bit_serial_predicate_domain.py']
probe=OUT/'review3371-source-probe-r6.py'
probe.write_text('from pathlib import Path\nimport hashlib,json\npaths='+repr(products+tests)+'\nprint(json.dumps({p:hashlib.sha256((Path("/plugin")/p).read_bytes()).hexdigest() for p in paths}))\n')
results={}
for arm in ['base','candidate','reverse','restore']:
 root=roots['base' if arm=='base' else 'candidate']
 mounts=[(root,'/plugin'),(probe,'/probe.py')]
 if arm=='base':mounts.extend((roots['candidate']/rel,'/plugin/'+rel) for rel in tests)
 if arm=='reverse':mounts.extend((roots['base']/rel,'/plugin/'+rel) for rel in products)
 name='review3371-source-r6p1-'+arm+'-8hd8'
 argv=['docker','run','--name',name,'--network','none','--read-only','--user','1000:1000','--cpus','1','--memory','512m','--memory-swap','512m','--tmpfs','/tmp:rw,nosuid,nodev,size=10485760,mode=1777','-e','PYTHONDONTWRITEBYTECODE=1']
 for source,target in mounts:argv.extend(['--mount','type=bind,src='+str(source)+',dst='+target+',readonly'])
 argv.extend(['ghcr.io/vibeic/vibeic-eda@sha256:97fb48e8ed7c61697818144586b601cfa6e932abef7842588a0384b6aeb5a5e5','--skip','python3','/probe.py'])
 run=subprocess.run(argv,capture_output=True,text=True)
 assert run.returncode==0,(arm,run.stderr)
 actual=json.loads(run.stdout.splitlines()[-1]);info=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
 expected={rel:hashlib.sha256((roots['base' if arm in ['base','reverse'] else 'candidate']/rel).read_bytes()).hexdigest() for rel in products}
 expected.update({rel:hashlib.sha256((roots['candidate']/rel).read_bytes()).hexdigest() for rel in tests})
 assert actual==expected,arm
 assert all(not m['RW'] for m in info['Mounts'] if m['Type']=='bind')
 results[arm]={'actual_sha256':actual,'expected_sha256':expected,'mounts':info['Mounts'],'image':info['Image'],'argv':argv,'rc':run.returncode,'log':run.stdout+run.stderr,'scope':'Fresh RO in-container probes of effective product and frozen test bytes, including overlays;raw earlier launch fields remain unchanged.'}
 subprocess.run(['docker','rm',name],check=True,stdout=subprocess.DEVNULL)
(OUT/'review3371-effective-source-r6.json').write_text(json.dumps({'head':row['head'],'tree':row['tree'],'base':row['base_head'],'arms':results,'verdict':'PASS','scope':'Effective source identity only,not product/IC acceptance'},indent=2)+'\n')
print('PASS:effective products base=reverse,candidate=restore;all four test files identical across all four arms')
