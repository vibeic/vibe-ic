from pathlib import Path
import hashlib,json,subprocess,collections,datetime
OUT=Path(__file__).resolve().parent
WORK=Path('/home/reyerchu/codex_tasks/work/audit-nonqualifying-integration54-20261021')
PREFIX=Path('vibe-ic-marketplace/plugins/vibe-ic')
SOURCE=Path('/home/reyerchu/.codex/plugins/cache/vibe-ic-marketplace/vibe-ic/1.30.54')
r=json.loads((OUT/'review3371-ro-r6-controls-readback.json').read_text())
assert r['head']=='85a1bdd67e138fb6063eca5fce6f69fd2f952b14'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==r['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
arms=r['arms']; names=['base','candidate','reverse','restore']
ids=[arms[a]['ids'] for a in names]
assert all(len(x)==165 and x.keys()==ids[0].keys() for x in ids)
assert ids[0]==ids[2] and ids[1]==ids[3] and set(ids[1].values())=={'PASS'}
assert [arms[a]['rc'] for a in names]==[1,0,1,0]
assert all(x not in {'ERROR','SKIP'} for row in ids for x in row.values())
assert sum(v=='FAIL' for v in ids[0].values())==25
for a in ['base','reverse']:
 subprocess.run(['python3',str(SOURCE/'programs/control_substance_check.py'),'--junit',str(OUT/f'review3371-ro-r6-{a}.xml'),'--json',str(OUT/f'review3371-ro-r6-{a}-substance.json'),'--advisory'],check=True)
 d=json.loads((OUT/f'review3371-ro-r6-{a}-substance.json').read_text())['primary']
 fail=[v for v in d['cases'] if v['bucket']!='passed']
 assert len(fail)==25 and all(v['bucket']=='observed_value' for v in fail)
for name,mapping in arms['candidate']['pinned_files_sha256'].items():
 ref=r['head'] if name=='candidate' else r['base_head']
 for rel,sha in mapping.items():
  raw=subprocess.check_output(['git','show',ref+':'+str(PREFIX/rel)],cwd=WORK)
  assert hashlib.sha256(raw).hexdigest()==sha,(name,rel)
field=json.loads((OUT/'review3371-final-r6-p0-comparison.json').read_text())
assert field['head']==r['head'] and field['tree']==r['tree'] and field['base_head']==r['base_head']
summary={'at':datetime.datetime.now().astimezone().isoformat(),'head':r['head'],'tree':r['tree'],'base_head':r['base_head'],'same_ids':165,'arms':{a:{'rc':arms[a]['rc'],'counts':dict(collections.Counter(arms[a]['ids'].values()))} for a in names},'substance':{'base':'25VALUE,0presence,0undecided','reverse':'25VALUE,0presence,0undecided'},'matched_source_hashes':True,'read_only_source_and_no_rw_alias':True,'normal_p0':field,'scope':'Final source54 integration component controls and native consumers; other P0 fixture failures retained; whole-IC NOT_MEASURED'}
(OUT/'review3371-final-r6-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='normal_p0'},indent=2))
