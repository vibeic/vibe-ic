from pathlib import Path
import subprocess,json,hashlib,sys
root=Path(__file__).resolve().parent
selection=json.loads((root/'selection.json').read_text())
program='/plugin/programs/interface_encoding_audit.py'
results={};failures=[]
for name,selected in selection.items():
 case=root/name
 a=subprocess.run(['python3',program,'--rtl-dir','rtl','--top-module','neutral','-I','rtl','--out-dir','audit'],cwd=case,capture_output=True,text=True);(case/'audit.log').write_text(a.stdout+a.stderr);assert a.returncode==0,(name,a.returncode,a.stderr)
 report=json.loads((case/'audit/encoding_audit_report.json').read_text());edge=[e for e in report['interfaces'] if e['wire_name']=='link'];assert len(edge)==1
 assert report['summary']['total_interfaces']==len(report['interfaces'])==selected['expected_rows'],name
 c=subprocess.run(['iverilog','-g2012','-s','tb','-o','serial.vvp','rtl/neutral.v','tb.sv'],cwd=case,capture_output=True,text=True);(case/'compile.log').write_text(c.stdout+c.stderr);assert c.returncode==0,(name,c.stderr)
 s=subprocess.run(['vvp','serial.vvp'],cwd=case,capture_output=True,text=True);(case/'native-simulation.log').write_text(s.stdout+s.stderr);assert s.returncode==selected['expected_simulation_rc'],(name,s.returncode,s.stdout)
 if not name.startswith('valid_'):assert 'binary=2 observed=3' in s.stdout and 'SERIAL_GRAY_BINARY_MISMATCH' in s.stdout
 else:assert 'VALID_SCALAR_CONTROL_PASS cases=4' in s.stdout
 valid=edge[0]['status']==selected['expected_status']
 if not valid:failures.append(name)
 results[name]={'expected_status':selected['expected_status'],'contract_pass':valid,'edge':edge[0],'summary':report['summary'],'audit_rc':a.returncode,'compile_rc':c.returncode,'simulation_rc':s.returncode,'simulation':s.stdout,'source_sha256':hashlib.sha256((case/'rtl/neutral.v').read_bytes()).hexdigest(),'tb_sha256':hashlib.sha256((case/'tb.sv').read_bytes()).hexdigest()}
x={'source':'85a1bdd67e138fb6063eca5fce6f69fd2f952b14','tree':'bd81308b8dca2de6086dabccb1e2abc935c4db96','version':'1.30.54-candidate-PR3371','image':'sha256:97fb48e8ed7c61697818144586b601cfa6e932abef7842588a0384b6aeb5a5e5','cases':results,'contract_failures':failures,'contract_passed':len(results)-len(failures),'contract_failed':len(failures),'scope':'Exact10 source/TB pairs from original53 epochs, immutable inputs. PR3371localmerge compatibility; notinstalledofficialsource, notICacceptance,not3378repair.'}
(root/'readback.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'passed':x['contract_passed'],'failed':x['contract_failed'],'value_failures':failures}),flush=True);sys.exit(1 if failures else 0)
