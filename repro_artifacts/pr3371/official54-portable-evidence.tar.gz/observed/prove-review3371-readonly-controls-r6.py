"""Exact owning IDs in immutable exports; product-only reverse and restore."""
from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
WORK = Path('/home/reyerchu/codex_tasks/work/audit-nonqualifying-integration54-20261021')
PREFIX = Path('vibe-ic-marketplace/plugins/vibe-ic')
IMAGE = 'ghcr.io/vibeic/vibeic-eda@sha256:97fb48e8ed7c61697818144586b601cfa6e932abef7842588a0384b6aeb5a5e5'
HEAD = subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
TREE = subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=WORK,text=True).strip()
assert HEAD == '85a1bdd67e138fb6063eca5fce6f69fd2f952b14'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
base_head = 'ae5600157f8ac19e63ce21e92a8de51e07ded91c'
exports = {}
for name, ref in [('base',base_head),('candidate',HEAD)]:
    root = WORK.parent / ('installed-review3371-r6-' + name + '-' + ref[:7])
    assert not root.exists()
    root.mkdir()
    archive = OUT / ('review3371-r6-' + name + '-' + ref[:7] + '.tar')
    subprocess.run(['git','archive','--format=tar','--output='+str(archive),ref,str(PREFIX)],cwd=WORK,check=True)
    subprocess.run(['tar','-xf',str(archive),'-C',str(root)],check=True)
    exports[name] = root / PREFIX
tests = ['programs/tests/test_project_outputs_in_tree_check.py',
         'programs/tests/test_interface_encoding_audit.py',
         'programs/tests/test_issue3252_native_sv_driver.py',
         'programs/tests/test_issue3378_bit_serial_predicate_domain.py']
selection = tests[:2] + [tests[2]+'::test_sv_native_driver_uses_selected_top_params_defines_and_no_implicit_synthesis',
                         tests[2]+'::test_verilog_native_driver_retains_read_verilog'] + [tests[3]]
products = ['_shared/skill_compliance_check.py','programs/project_outputs_in_tree_check.py',
            'programs/flow_compliance_check.py','programs/rtl_hygiene_lint.py',
            'programs/interface_encoding_audit.py']
hashes = {name:{rel:hashlib.sha256((root/rel).read_bytes()).hexdigest() for rel in tests+products}
          for name,root in exports.items()}
results = {}
for arm in ('base','candidate','reverse','restore'):
    root = exports['base' if arm == 'base' else 'candidate']
    mounts = [{'source':str(root),'target':str(root),'readonly':True},
              {'source':str(OUT),'target':str(OUT),'readonly':False}]
    if arm == 'base':
        mounts += [{'source':str(exports['candidate']/rel),'target':str(root/rel),'readonly':True}
                   for rel in tests]
    if arm == 'reverse':
        mounts += [{'source':str(exports['base']/rel),'target':str(root/rel),'readonly':True}
                   for rel in products]
    name = 'review3371-ro-r6-' + arm
    container = name + '-8hd8'
    cmd = ['docker','run','--name',container,'--network','none','--read-only',
           '--user','1000:1000','--cpus','4','--memory','16g','--memory-swap','16g',
           '--tmpfs','/tmp:rw,nosuid,nodev,size=536870912,mode=1777',
           '-w',str(root),'-e','PYTHONDONTWRITEBYTECODE=1',
           '-e','PYTHONPATH='+str(root/'programs')]
    for mount in mounts:
        cmd += ['--mount','type=bind,src='+mount['source']+',dst='+mount['target']+
                (',readonly' if mount['readonly'] else '')]
    cmd += [IMAGE,'--skip','python3','-m','pytest','-q',*selection,'-p','no:cacheprovider',
            '--basetemp='+str(OUT/(name+'-tmp')),'--junitxml='+str(OUT/(name+'.xml'))]
    with (OUT/(name+'.log')).open('w') as stream:
        done = subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
    inspect = json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
    actual = inspect['Mounts']
    for mount in actual:
        if mount['Type'] != 'bind' or not mount['RW']:
            continue
        writable = Path(mount['Source'])
        for source in exports.values():
            assert not source.is_relative_to(writable) and not writable.is_relative_to(source), mount
    assert inspect['HostConfig']['ReadonlyRootfs'] is True
    assert inspect['State']['ExitCode'] == done.returncode
    xml = OUT/(name+'.xml')
    if not xml.exists():
        raise RuntimeError('no JUnit; this is NOT a measured red: '+str(OUT/(name+'.log')))
    ids = {case.attrib['classname']+'::'+case.attrib['name']:
           ('FAIL' if case.find('failure') is not None else
            'ERROR' if case.find('error') is not None else
            'SKIP' if case.find('skipped') is not None else 'PASS')
           for case in ET.parse(xml).findall('.//testcase')}
    result = {'argv':cmd,'rc':done.returncode,'ids':ids,'mounts':actual,
              'readonly_rootfs':True,'container_image':inspect['Image'],
              'head':HEAD,'tree':TREE,'base_head':base_head,'exports':{k:str(v) for k,v in exports.items()},
              'pinned_files_sha256':hashes,
              'source_scope':'all source mounts read-only; no writable source ancestor/descendant alias in this container'}
    (OUT/(name+'-launch.json')).write_text(json.dumps(result,indent=2)+'\n')
    results[arm]=result
    print(json.dumps({'arm':arm,'rc':done.returncode,'counts':{s:list(ids.values()).count(s)
          for s in ('PASS','FAIL','ERROR','SKIP')},'image':inspect['Image']}),flush=True)
    assert done.returncode == (1 if arm in ('base','reverse') else 0)
    assert len(ids) >= 158 and not {'ERROR','SKIP'}.intersection(ids.values())
    subprocess.run(['docker','rm',container],check=True,stdout=subprocess.DEVNULL)
assert results['base']['ids'] == results['reverse']['ids']
assert results['candidate']['ids'] == results['restore']['ids']
assert all(row == 'PASS' for row in results['candidate']['ids'].values())
assert all(results['base']['ids'].keys() == r['ids'].keys() for r in results.values())
for name,root in exports.items():
    assert all(hashlib.sha256((root/rel).read_bytes()).hexdigest() == sha for rel,sha in hashes[name].items())
(OUT/'review3371-ro-r6-controls-readback.json').write_text(json.dumps({
    'head':HEAD,'tree':TREE,'base_head':base_head,'arms':results,
    'scope':'two owning files, two exact native-script owner nodes, and existing five producer-domain controls affected by the official54 merge; no other suite; four immutable-export arms; not IC acceptance'},indent=2)+'\n')
