"""Actual unfiltered P0 dispatcher; only the adversarial receipt is mutated."""
from pathlib import Path
import collections
import hashlib
import json
import subprocess
import sys
import time

plugin, project, case_root, scene, output = sys.argv[1:]
plugin, project, case_root, output = map(Path, (plugin, project, case_root, output))
sys.path.insert(0,str(plugin/'programs'))
import flow_compliance_check as flow
registered = tuple(flow._STRUCTURAL_RTL_GATES)
assert len(registered) == len(set(registered)) == 243
older = None
if scene == 'replay':
    prior = case_root / 'prior'
    rtl = prior/'phase2/stage1/rtl'
    rtl.mkdir(parents=True)
    (rtl/'neutral.v').write_text("\n`ifdef OMITTED\n`endif\nmodule producer(output reg [5:0] count);\n initial count <= 6'd0;\nendmodule\nmodule consumer(input [5:0] count);\n always @* if(count == 6'd3) begin end\nendmodule\nmodule neutral;\n wire [5:0] count;\n producer p(.count(count)); consumer c(.count(count));\nendmodule\n")
    out = prior/'.vibeic-state/audit_receipts/prior/interface_encoding_audit'
    cmd = [sys.executable,str(plugin/'programs/interface_encoding_audit.py'),
           '--rtl-dir',str(rtl),'--top-module','neutral','--out-dir',str(out)]
    setup = subprocess.run(cmd,capture_output=True,text=True)
    (case_root/'prior-producer.log').write_text(setup.stdout+setup.stderr)
    assert setup.returncode == 0
    older = json.loads((out/'encoding_audit_report.json').read_text())['configuration']

actual = flow._watchdog.run_host_supervised
calls = []
tampered = []
def execute(argv, **kw):
    result = actual(argv, **kw)
    gate = next((Path(a).stem for a in argv if a.endswith('.py')), '')
    if gate == 'interface_encoding_audit' and scene == 'replay':
        receipt = Path(argv[argv.index('--out-dir')+1])/'encoding_audit_report.json'
        before = receipt.read_bytes()
        payload = json.loads(before)
        payload['configuration']['native_context'] = older['native_context']
        payload['configuration']['native_context_sha256'] = older['native_context_sha256']
        receipt.write_text(json.dumps(payload,indent=2)+'\n')
        tampered.append({'receipt':str(receipt),'before_sha256':hashlib.sha256(before).hexdigest(),
                        'after_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),
                        'mutation':'only context pointer/hash replayed from actual prior producer'})
    row = {'gate':gate,'actual_rc':result.rc,'outcome':result.outcome}
    calls.append(row)
    print(json.dumps(row),flush=True)
    return result
flow._watchdog.run_host_supervised = execute
records=[]
started=time.time()
dispatch=flow._run_structural_rtl_gates(project,records_out=records)
assert [r['name'] for r in records] == list(registered)
assert all(n==1 for n in collections.Counter(r['gate'] for r in calls).values())
by_name={r['name']:r for r in records}
selected={k:by_name[k] for k in ('interface_encoding_audit','project_outputs_in_tree_check')}
result={'source':str(plugin),'project':str(project),'scene':scene,'registered':len(registered),
        'records':records,'selected':selected,'counts':dict(collections.Counter(r['verdict'] for r in records)),
        'actual_subprocesses':len(calls),'actual_call_ledger':calls,'dispatch':dispatch,
        'tampered':tampered,'seconds':time.time()-started,
        'scope':'Normal unfiltered 243-record P0; actual native producer and gate consumers. Fixture outputs are incomplete; no whole-P0 or IC PASS claim.'}
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'scene':scene,'selected':{k:v['verdict'] for k,v in selected.items()},
                  'counts':result['counts'],'seconds':result['seconds']}),flush=True)
