# Portable original historical-report compatibility evidence — PR3371

This supplies the author-owned original inputs previously referred to only by local paths and hashes. It is not a synthetic substitute for the six historical reports, not the full3.1GB IC project, and not a SHA256-project corpus.

`fixture/` contains exactly60 unchanged source/design files and six full original negative audit JSON reports. `manifest.json` pins all66 SHA256 values. No missing historical native proof is recreated. `replay-fixture/` separately contains three explicitly synthetic negative-control inputs; these are never described as historical reports.

The source base is official v1.30.51 `50e09a9c3813b1487806667bdc430dce3726b32d`, tree `b52296b08f9cea4b41f806aad08dd36c0ad7cefa`. The exact PR candidate is `abeaf1df50ee26c248911871f340c1233bf246b6`, tree `70d6d5f63c6b541d365049db63fab2b83dae8776`. This is not v1.30.52 shipping-tree qualification.

## Reproduce on another machine

Prerequisites: Python3.10+, Git, Docker and access to the pinned public image. No SSH to the author's host, original HOME, historical plugin cache, API key, installed plugin patch or oracle corpus is required.

Pull the exact image once:

```sh
docker pull ghcr.io/vibeic/vibeic-eda@sha256:97fb48e8ed7c61697818144586b601cfa6e932abef7842588a0384b6aeb5a5e5
```

After extracting this archive, run:

```sh
python3 reproduce.py --out /a/new/empty/output-directory
```

The runner fetches the two exact public Git commits into its own bare repository, verifies their full tree IDs and exports the complete plugin prefix. Alternatively, an existing local Git repository can be used read-only:

```sh
python3 reproduce.py --repo /path/to/vibe-ic-clone --out /a/new/empty/output-directory
```

Only one plugin export and the exact `p0_driver.py` are mounted read-only. Each case gets its own writable project copy and output directory. The container's historical project address is preserved solely to keep original report bytes unchanged; it is an arbitrary Docker destination and imposes no host username/home requirement. Neither HOME nor any original host/project directory is mounted.

The four arms are base, candidate, product-only reverse (five product files), and restore. Each arm runs two actual unfiltered243-record normal-P0 dispatches. The driver logs real subprocess return codes and mutates only the explicitly adversarial context pointer/hash after an actual native producer returns. It does not author producer results or filter the registry.

Expected selected-consumer results:

| Scene | Base | Candidate | Reverse | Restore |
|---|---|---|---|---|
| Real historical reports: storage | FAIL | PASS | FAIL | PASS |
| Real historical reports: encoding | INCOMPLETE | INCOMPLETE | INCOMPLETE | INCOMPLETE |
| Prior-context replay: encoding | PASS | INCOMPLETE | PASS | INCOMPLETE |
| Prior-context replay: storage | FAIL | FAIL | FAIL | FAIL |

All243 IDs and all241 non-target verdicts must remain equal within a scene; every original input/report byte and exported source file is rehashed after execution. Real-history cases execute159 actual child processes, replay cases223;243 registry records are not represented as243 executed processes. Other fixture FAIL/INCOMPLETE/BLOCKED results are retained. No whole-P0, Phase2, physical flow or IC PASS is claimed.

## Included measurements

`observed/` holds the measured eight sparse-mount P0 reports, real child logs and actual Docker mount/image metadata from the author's execution of this exact runner. `fresh-native-map.json` and `fresh-native-objects/` preserve the actual newly generated encoding receipts/context/design/script/log bytes by content hash to avoid repeated large identical native models. These are fresh reproduction outputs, not replacements for missing historical proofs. Reproduction generates its own fresh outputs instead of restoring these caches.

The same final source's owning158-ID RGR/restore and25 observed-value red controls are preserved in PR3371's earlier public test packets. This portable runner addresses the original-data availability and read-dependency closure needed for historical compatibility. The official main/installation and whole-IC run remain separately identified.

SERV RTL retains its original per-file SPDX copyright notices. The upstream ISC permission notice is included under `licenses/`.
