
`ifdef OMITTED
`endif
module producer(output reg [5:0] count);
 initial count <= 6'd0;
endmodule
module consumer(input [5:0] count);
 always @* if(count == 6'd3) begin end
endmodule
module neutral;
 wire [5:0] count;
 producer p(.count(count)); consumer c(.count(count));
endmodule
