// SPDX-License-Identifier: Apache-2.0
// Author: Codex IC Expert, Vibe-IC catalog-glue-author.
// Integration authored from input/docs/L2, L3, L7, L8, L9 only.
// Reused SERV/servile sources retain their ISC/Apache-2.0 licenses and the
// catalog producer's exact official-parent/errata/local-derivative receipts.
// No benchmark reference top or reference SRAM wrapper was consulted.
// DECLARED CHOICES: plugin_input/design_choices.json, published through
// spec_declaration_emit. External SRAM is a single byte array shared by
// instructions, data and RF. Reads are asynchronous at the registered address;
// writes commit on i_clk posedge when cyc && we. There is NO extra read flop.
// RF read and write slots are disjoint for the selected rf_width=8 protocol.
// Reset qualifies the external clock-sampled write, including the FIRST edge;
// it never clears the external array or asynchronously resets internal state.
`default_nettype none
module subservient #(
    parameter integer memsize = 1024,
    parameter [31:0] RESET_PC = 32'h00000000,
    parameter integer WITH_CSR = 1,
    parameter integer SRAM_AW = $clog2(memsize)
) (
    input wire i_clk,
    input wire i_rst,
    input wire i_gpio,
    output reg [SRAM_AW-1:0] o_sram_addr,
    output reg [7:0] o_sram_data,
    input wire [7:0] i_sram_data,
    output wire o_sram_we,
    output wire o_sram_cyc,
    output reg o_gpio
);
    localparam integer RF_REGS = 32 + WITH_CSR*4;
    localparam integer RF_AW = $clog2(RF_REGS*4);
    wire [31:0] mem_addr, mem_wdata, mem_rdata;
    wire [3:0] mem_sel;
    wire mem_we, mem_stb, mem_ack;
    wire [31:0] ext_addr, ext_wdata;
    wire [3:0] ext_sel;
    wire ext_we, ext_stb;
    reg ext_ack;
    wire [31:0] ext_rdata = {31'd0, o_gpio};
    wire [RF_AW-1:0] rf_waddr, rf_raddr;
    wire [7:0] rf_wdata, rf_rdata;
    wire rf_wen, rf_ren;
    reg irq_meta, irq_sync;
    always @(posedge i_clk) begin
        irq_meta <= i_gpio;
        irq_sync <= irq_meta;
        if (i_rst) begin
            irq_meta <= 1'b0;
            irq_sync <= 1'b0;
        end
    end

    servile #(
        .width(1), .rf_width(8), .reset_pc(RESET_PC),
        .reset_strategy("MINI"), .with_csr(WITH_CSR != 0),
        .with_c(1'b0), .with_mdu(1'b0), .sim(1'b0), .debug(1'b0)
    ) cpu (
        .i_clk(i_clk), .i_rst(i_rst), .i_timer_irq(irq_sync),
        .o_wb_mem_adr(mem_addr), .o_wb_mem_dat(mem_wdata),
        .o_wb_mem_sel(mem_sel), .o_wb_mem_we(mem_we),
        .o_wb_mem_stb(mem_stb), .i_wb_mem_rdt(mem_rdata),
        .i_wb_mem_ack(mem_ack),
        .o_wb_ext_adr(ext_addr), .o_wb_ext_dat(ext_wdata),
        .o_wb_ext_sel(ext_sel), .o_wb_ext_we(ext_we),
        .o_wb_ext_stb(ext_stb), .i_wb_ext_rdt(ext_rdata),
        .i_wb_ext_ack(ext_ack),
        .o_rf_waddr(rf_waddr), .o_rf_wdata(rf_wdata),
        .o_rf_wen(rf_wen), .o_rf_raddr(rf_raddr),
        .i_rf_rdata(rf_rdata), .o_rf_ren(rf_ren)
    );

    wire [SRAM_AW-1:0] sram_waddr, sram_raddr;
    wire [7:0] sram_wdata;
    wire sram_wen, sram_ren;
    servile_rf_mem_if #(.depth(memsize), .rf_regs(RF_REGS)) shared_memory_adapter (
        .i_clk(i_clk), .i_rst(i_rst),
        .i_waddr(rf_waddr), .i_wdata(rf_wdata), .i_wen(rf_wen),
        .i_raddr(rf_raddr), .o_rdata(rf_rdata), .i_ren(rf_ren),
        .o_sram_waddr(sram_waddr), .o_sram_wdata(sram_wdata),
        .o_sram_wen(sram_wen), .o_sram_raddr(sram_raddr),
        .i_sram_rdata(i_sram_data), .o_sram_ren(sram_ren),
        .i_wb_adr(mem_addr[SRAM_AW-1:2]), .i_wb_dat(mem_wdata),
        .i_wb_sel(mem_sel), .i_wb_we(mem_we), .i_wb_stb(mem_stb),
        .o_wb_rdt(mem_rdata), .o_wb_ack(mem_ack)
    );

    reg write_launch, cycle_launch;
    always @(posedge i_clk) begin
        // Defined idle pins: an unreset RF scratch value is not a transaction.
        o_sram_addr <= (sram_wen | sram_ren)
            ? (sram_wen ? sram_waddr : sram_raddr) : {SRAM_AW{1'b0}};
        o_sram_data <= sram_wen ? sram_wdata : 8'd0;
        write_launch <= sram_wen;
        cycle_launch <= sram_wen | sram_ren;
        if (i_rst) begin
            o_sram_addr <= {SRAM_AW{1'b0}};
            o_sram_data <= 8'd0;
            write_launch <= 1'b0;
            cycle_launch <= 1'b0;
        end
    end
    assign o_sram_we = write_launch & !i_rst;
    assign o_sram_cyc = cycle_launch & !i_rst;

    always @(posedge i_clk) begin
        ext_ack <= ext_stb & !ext_ack;
        if (ext_stb && !ext_ack && ext_we && ext_sel[0]
                && ext_addr == 32'h40000000)
            o_gpio <= ext_wdata[0];
        if (i_rst) begin
            ext_ack <= 1'b0;
            o_gpio <= 1'b0;
        end
    end
endmodule
`default_nettype wire
