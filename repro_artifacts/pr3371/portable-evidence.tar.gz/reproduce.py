"""Replay immutable original report bytes using public exact source refs and sparse Docker mounts."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,collections,hashlib,json,os,shutil,subprocess,tarfile,datetime

HERE=Path(__file__).resolve().parent
META=json.loads((HERE/'manifest.json').read_text())
PREFIX=Path('vibe-ic-marketplace/plugins/vibe-ic')
PRODUCTS=['_shared/skill_compliance_check.py','programs/project_outputs_in_tree_check.py',
          'programs/flow_compliance_check.py','programs/rtl_hygiene_lint.py','programs/interface_encoding_audit.py']

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def command(argv,**kw):return subprocess.check_output(argv,text=True,**kw).strip()
def extract(archive,dest):
 with tarfile.open(archive) as tar:
  for m in tar.getmembers():
   path=Path(m.name)
   if path.is_absolute() or '..' in path.parts:raise ValueError('unsafe archive member')
   if m.issym() or m.islnk():
    target=(dest/path.parent/m.linkname).resolve()
    if not target.is_relative_to(dest.resolve()):raise ValueError('unsafe archive link')
  tar.extractall(dest)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--out',required=True,type=Path,help='New empty output directory; never the immutable fixture')
 parser.add_argument('--repo',type=Path,help='Optional existing Git repo with both public exact commits; read only')
 args=parser.parse_args()
 output=args.out.resolve();output.mkdir(parents=True,exist_ok=False)
 for group,folder in [('files','fixture'),('replay_files','replay-fixture')]:
  assert all(sha(HERE/folder/p)==v['sha256'] for p,v in META[group].items()),group
 repo=args.repo.resolve() if args.repo else output/'public-source.git'
 if not args.repo:
  subprocess.run(['git','init','--bare','--quiet',str(repo)],check=True)
  subprocess.run(['git','-C',str(repo),'fetch','--depth','1','https://github.com/vibeic/vibe-ic.git',META['base'],META['candidate']],check=True)
 sources={}
 source_hashes={}
 for arm in ['base','candidate']:
  ref=META[arm]
  assert command(['git','-C',str(repo),'rev-parse',ref+'^{tree}'])==META['source_trees'][arm]
  archive=output/(arm+'.tar')
  subprocess.run(['git','-C',str(repo),'archive','--format=tar','--output='+str(archive),ref,str(PREFIX)],check=True)
  dest=output/('source-'+arm);dest.mkdir();extract(archive,dest)
  sources[arm]=dest/PREFIX
  source_hashes[arm]={str(p.relative_to(sources[arm])):sha(p) for p in sources[arm].rglob('*') if p.is_file()}
 subprocess.run(['docker','image','inspect',META['image']],check=True,stdout=subprocess.DEVNULL)
 results={}
 def one(arm,scene):
  source=sources['base' if arm=='base' else 'candidate']
  case=output/(arm+'-'+scene);case.mkdir()
  data=case/'project';folder='fixture' if scene=='real' else 'replay-fixture'
  shutil.copytree(HERE/folder,data)
  before=META['files' if scene=='real' else 'replay_files']
  name='pr3371-'+arm+'-'+scene+'-'+str(os.getpid())
  mounts=[(source,'/plugin',True),(HERE/'p0_driver.py','/p0_driver.py',True),
          (data,META['project_container_path'],False),(case,'/result',False)]
  if arm=='reverse':mounts += [(sources['base']/rel,'/plugin/'+rel,True) for rel in PRODUCTS]
  argv=['docker','run','--name',name,'--network','none','--read-only','--user',str(os.getuid())+':'+str(os.getgid()),
        '--cpus','6','--memory','24g','--memory-swap','24g','--tmpfs','/tmp:rw,nosuid,nodev,size=536870912,mode=1777',
        '-e','PYTHONDONTWRITEBYTECODE=1','-e','VIBE_IC_COMPLIANCE_WORKERS=4','-w',META['project_container_path']]
  for host,target,ro in mounts:argv += ['--mount','type=bind,src='+str(host)+',dst='+target+(',readonly' if ro else '')]
  argv += [META['image'],'--skip','python3','/p0_driver.py','/plugin',META['project_container_path'],
           '/result','clean' if scene=='real' else 'replay','/result/p0.json']
  with (case/'docker.log').open('w') as log:run=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
  info=json.loads(command(['docker','inspect',name]))[0]
  actual=info['Mounts']
  assert info['HostConfig']['ReadonlyRootfs'] is True
  for m in actual:
   if m['Type']=='bind' and m['RW']:
    writable=Path(m['Source'])
    assert all(not s.is_relative_to(writable) and not writable.is_relative_to(s) for s in sources.values())
  (case/'launch.json').write_text(json.dumps({'argv':argv,'natural_rc':run.returncode,'image':info['Image'],
      'mounts':actual,'no_home_or_external_project_mount':True,'source_postimages':{rel:sha(source/rel) for rel in PRODUCTS}},indent=2)+'\n')
  assert run.returncode==0,(arm,scene,case/'docker.log')
  assert all(sha(data/rel)==v['sha256'] for rel,v in before.items())
  report=json.loads((case/'p0.json').read_text())
  assert report['registered']==len(report['records'])==243
  selected={n:v['verdict'] for n,v in report['selected'].items()}
  if scene=='real':expected={'interface_encoding_audit':'INCOMPLETE','project_outputs_in_tree_check':('FAIL' if arm in ('base','reverse') else 'PASS')}
  else:expected={'interface_encoding_audit':('PASS' if arm in ('base','reverse') else 'INCOMPLETE'),'project_outputs_in_tree_check':'FAIL'}
  assert selected==expected,(arm,scene,selected)
  subprocess.run(['docker','rm',name],check=True,stdout=subprocess.DEVNULL)
  result={'selected':selected,'counts':report['counts'],'protected_files':len(before),'image':info['Image'],
          'actual_subprocesses':report['actual_subprocesses'],'report':str(case/'p0.json'),'launch':str(case/'launch.json')}
  print(json.dumps({'arm':arm,'scene':scene,**result}),flush=True)
  return result
 for arm in ['base','candidate','reverse','restore']:
  with ThreadPoolExecutor(max_workers=2) as pool:
   jobs={scene:pool.submit(one,arm,scene) for scene in ['real','replay']}
   results[arm]={scene:future.result() for scene,future in jobs.items()}
 for scene in ['real','replay']:
  maps={a:{r['name']:r['verdict'] for r in json.loads(Path(results[a][scene]['report']).read_text())['records']} for a in results}
  assert maps['base']==maps['reverse'] and maps['candidate']==maps['restore']
  untouched=lambda m:{k:v for k,v in m.items() if k not in ('interface_encoding_audit','project_outputs_in_tree_check')}
  assert all(untouched(m)==untouched(maps['base']) for m in maps.values())
 for name,root in sources.items():assert all(sha(root/p)==digest for p,digest in source_hashes[name].items())
 summary={'at':datetime.datetime.now().astimezone().isoformat(),'base':META['base'],'candidate':META['candidate'],
          'source_trees':META['source_trees'],'arms':results,'same_registry_ids':243,'unchanged_non_target_verdicts':241,
          'fixture_files_unchanged':True,'source_files_unchanged':True,'portable_mounts':'Only one pluginRO,driverRO,isolatedproject/resultRW; no HOME, historical install cache or another machine.',
          'scope':'Actual normal P0 consumers on the exact original historical subset plus a separate synthetic replay control. Other fixture failures remain; no whole-P0, SHA256-project or whole-IC PASS.'}
 (output/'readback.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('COMPONENT REPRODUCTION COMPLETE; WHOLE IC NOT_MEASURED',flush=True)
if __name__=='__main__':main()
