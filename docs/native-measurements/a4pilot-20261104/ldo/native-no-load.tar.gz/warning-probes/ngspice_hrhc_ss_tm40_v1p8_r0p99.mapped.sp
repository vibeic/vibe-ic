* LDO no-load quiescent power from the delivered post-layout netlist.
.lib "/mnt/ssd2/tmp/cx-a4-step49/ldo/input/pdk/models/cornerMOShv.lib" mos_ss
.lib "/mnt/ssd2/tmp/cx-a4-step49/ldo/input/pdk/models/cornerCAP.lib" cap_typ
.lib "/mnt/ssd2/tmp/cx-a4-step49/ldo/input/pdk/models/cornerRES.lib" res_typ
.include "/mnt/ssd2/tmp/cx-a4-step49/ldo/phase3/librelane/analog/ldo/native_analog/pex_ngspice_hrhc.bound.spice"
.include "/mnt/ssd2/tmp/cx-a4-ldo-leakage/ngspice_hrhc.wrapper.spice"
.temp -40
VDD vdd 0 1.8
VREF vref 0 0.99
XU vdd 0 vref vout ldo__a8_interface
.nodeset v(vout)=1.2
.options reltol=1e-5 trtol=1 method=gear
.control
set noaskquit
set num_threads=1
op
let iq_a = -i(VDD)
let power_w = v(vdd)*iq_a
let vout_v = v(vout)
print iq_a power_w vout_v
let nr11_i1_c = v(vout)-v(xu.a8_rc_p0383)
let nr11_i2_c = v(xu.a8_rc_p0035)-v(xu.a8_rc_p0383)
let nr63_i1_c = v(xu.a8_rc_p0035)-v(xu.a8_rc_p0400)
let nr63_i2_c = v(xu.a8_rc_p0393)-v(xu.a8_rc_p0400)
print nr11_i1_c nr11_i2_c nr63_i1_c nr63_i2_c
showmod n.xu.xnative.x11.nr1
quit
.endc
.end
