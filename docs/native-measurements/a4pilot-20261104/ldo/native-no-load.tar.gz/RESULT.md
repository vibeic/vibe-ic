405/405 no-load OP，405/405 Liberty 原生讀取／link／power，135 個 RC/PVT 選定 views。Iq 30.75744–47.53473 µA；P 49.21190–95.06947 µW；Vout 1.187202–1.216568 V。

本項完成第 49 步 Analog characterized views 的 LDO no-load leakage 實測。它不宣稱 DSM timing 或整個 ADC 已完成。依使用者最新裁定，Vout 沒有外接負載，保留實體抽取網表內的 feedback divider、偏壓及全部 R/C。Native deck 沒有 i_load、RLOAD、gmin 覆寫或 floatcheck；保留先前核准的 .nodeset v(vout)=1.2 作為解的起始猜值，並由 ngspice 正常求解。

量測範圍為 5 RC style × 3 MOS corners × 3 溫度 × 3 Vin × 3 VREF = 405。RC style 為 ngspice、ngspice_hrhc、ngspice_hrlc、ngspice_lrhc、ngspice_lrlc；MOS 為 TT／SS／FF；溫度 -40／27／125 °C；Vin 1.6／1.8／2.0 V；VREF 0.99／1.0／1.01 V。TT／SS／FF 與溫度來自 case input/docs/L5_ANALOG_SPEC.md:55 與 requirements/base_A2/model_corner_statistics_coverage.json/documented_scope。Vin 來自 L5 的 1.6–2.0 V；VREF 來自 phase3/analog/ldo/spec.json/input_conditions 的正式 externally_driven_reference 宣告。無負載是最新使用者指示，不再保留先前的 0.1／0.5／1.0 mA load 軸。

重用 /mnt/ssd2/tmp/cx-a4-step49/ldo/phase3/librelane/analog/ldo/native_analog/pex_*.bound.spice 的五份既有抽取結果，沒有重跑 Magic。物理 GDS 是 d6c3da76e759dc2b567ba5603a6e480325892e2a608a8558354921255292d1c9，為已確認和 re-freeze 612ae31c XOR 0 的 main rebuild。端點轉接使用現有 _analog_a8_extraction_wrapper.build_wrapper 的一對一位置映射，沒有短接或省略任何原生 RC 節點。模型使用同一 case 的 cornerMOShv.lib mos_tt／mos_ss／mos_ff，cap_typ 與 res_typ 伴隨庫保持原來的組合。

每個 native ngspice log 直接列 iq_a=-i(VDD)、power_w=v(vdd)*iq_a、vout_v，供電來源為外部 VDD。405 個結果均滿足原 Iq≤50 µA 與 Vout 1.1–1.3 V 界線，沒有缺測。名義 ngspice／TT／27 °C／1.8 V／VREF=1.0 V 的 Iq=38.99316 µA，P=70.18769 µW，Vout=1.200338 V。這是 no-load 靜態值，不包含原先 0.5 mA 負載產生的 970.28 µW 輸入功率。

每個測得 corner 產生自身的 ldo.lib，leakage_power_unit 在 library 層為 1uW，cell_leakage_power 等於該點的原生 power_w×1e6。OpenSTA 3.1.0 逐份實際 read_liberty、link 一個 LDO 實例並 report_power，405/405 成功；OpenSTA 的 Macro leakage 與 ngspice 功率在列印精度內一致，並非只檢查檔案存在或文字格式。名義 OpenSTA leakage 為 7.01876925e-05 W，對照 ngspice 7.018769e-05 W。沒有替 LDO 加不存在的數位 timing arc。

給 die STA 整合者的簡潔選取為 selected_corners.tsv 與 selected/ 下的 135 份 ldo.lib。每一個 5 RC × 3 process × 3 溫度 × 3 Vin 組合，取其三個 VREF 實測功率中的最大值，完整保留被選到的原始 Liberty bytes。405 個原始 corner 都在 corners.tsv、results.json 與各自目錄，不以選取檔取代。此次 135 個最大值均來自 VREF=1.01 V；這是實際數值的選擇結果，沒有使用插值或另造最差值。

三個 OP 曾出現 r3_cmc vmax 警告，已逐一閱讀並補讀最終節點。它們是 ngspice_hrhc_ss_tm40_v1p8_r0p99、ngspice_hrlc_tt_t27_v1p8_r0p99、ngspice_lrlc_ss_t125_v1p6_r0p99。所有警告均出現在 dynamic gmin stepping 完成之前。對 R11／R63 的最終四個端對 body 電壓重讀，最大分別為 1.185731、1.186721、1.188989 V；ngspice showmod 直接讀到 r3_cmc vmax=9.9e9。最終 Iq、Vout 與功率完全重現原 OP，沒有 residual failure 或最終模型範圍超限。因此本次 AI review 將警告判為 Newton 迭代過程越界，沒有因此排除 corner 或改限值。warning-probes/*.mapped.log 保留原生證據。最初直接使用原 .subckt formal node 名稱的探測查無向量，該失敗觀測亦保留在同目錄；修正後依實際 wrapper 端點映射取得上述電壓。

一次嘗試把 405 corner 同時放進單一 OpenSTA session，原生回報 maximum scene count exceeded，保留於 sta-all.log。之後改為每份 Liberty 獨立 read／link／report_power，沒有減少 corner。這是工具的 session 容量限制，不是任何 Liberty 的解析失敗。

可重跑腳本為 run.py 與 read_liberties.py，暫存原件在 /mnt/ssd2/tmp/cx-a4-ldo-leakage。run.py 會保留已完成的 result.json，避免重跑相同 native 點。Nominal、matrix、405 個 OpenSTA 與功率比對的實際輸出分別在 nominal-run.log、matrix-run.log、liberty-reads.log、opensta_power_comparison.json。此次沒有修改 repo 或 plugin，沒有 source branch／commit，也沒有 push 或 main landing。既有 A8 自動 producer 仍需把其帶載 OP 語意改為本次明確的 no-load characterization；本次量測與可讀 Liberty 可先由原生工具交付，不等待舊 receipt／source claim 層。
